//
//  DemoPaymentTests.h
//  DemoPaymentTests
//
//  Created by Basil Abbas on 06/03/12.
//  Copyright (c) 2012 basil@tecsolsoftware.com. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface DemoPaymentTests : SenTestCase

@end
